# Readme for Calculator V 1.4.9.0_CUI_Dev_20220222
この高機能関数電卓「Calculator」は、V 1.4.9.0_CUI_Dev_20220222(2021/02/22)現在、 Python 3.9以上がインストールされたWindows、MacOS、Chrome OS、Linuxに対応しています。
当計算機中にて使用される計算記号の対応表を以下に記述します。
+: +
-: -
×: *
÷: /
^: **
√: //
万が一動作しない場合、OSが非対応か必要なライブラリがインストールされていない可能性があります。
以下に、当プログラムに使用しているライブラリを記述します。
・time
・sys
・math
・os
・datetime
・platform